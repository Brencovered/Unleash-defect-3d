# unleash-defect-3d

Places 2D AI detections onto a 3D point cloud and gives each one a real
coordinate, so a bounding box on a drone frame becomes a lat/lon a work order
can be raised against.

Built as a working prototype and a test harness. **Not production code.** It
exists so the platform team can see the algorithm working on real data, argue
with the numbers, and lift what's useful.

---

## Quick start

```bash
npm install
npm test          # 15 tests, runs against a real 227k-point Unleash export
npm run serve     # http://localhost:8080 for the browser tester
```

The browser tester also works with no server at all: open `web/index.html`
directly. Everything is inlined, nothing is uploaded, no network access.

---

## What it does

```
camera pose + intrinsics ──┐
                           ├──► ray per detection ──► intersect cloud ──► 3D hit
2D bounding box ───────────┘                                                │
                                                                            ▼
                        lat/lon, elevation, extent  ◄──  fuse hits across frames
```

A detection seen in eight overlapping frames becomes one defect with a
confidence signal, not eight pins.

### Accuracy

| Dataset | Detections | Result |
|---|---|---|
| Hill 60 treatment plant, real Unleash export, 227k pts, 16.6 pts/m² | 6 | 6/6 placed, 6 defects, all inside the cloud footprint |
| Synthetic, projected from 6 known 3D points into 24 views with 6 px jitter | 24 | 24/24 placed, exactly 6 defects, **mean 3D error 0.24 m, max 0.60 m** |

Both are asserted in `test/golden.test.mjs`. The synthetic case needs a 38 MB
LAZ that isn't committed (see Fixtures), so it skips rather than fails.

---

## The finding that matters most

**Media Drive already stores everything this needs.** Per-image metadata
carries `gimbalyawdegree`, `gimbalpitchdegree`, `gimbalrolldegree`, `gpslat`,
`gpslng`, `gpsalt`, `camfocallengthin35mmformat` and `exifimagewidth`. That is
a complete camera pose plus intrinsics, already parsed, already queryable.

The platform's COCO export drops the gimbal angles. Without them the pipeline
has to assume the camera pointed straight down, and on a 20 m flight every
5 degrees of real tilt shifts the result about 1.6 m on the ground. With them,
it's centimetres.

Production should query Media Drive directly and never touch a COCO file.
See `docs/API-NOTES.md`.

---

## Layout

```
src/core/        pure geometry, no I/O. The part that was hard to get right.
  las.js         LAS/LAZ header, VLRs, EPSG discovery, point decoding
  index3d.js     voxel-hashed point index and ray-march intersector
  pose.js        yaw/pitch/roll, omega/phi/kappa, nadir, pixel-to-ray
  fuse.js        clustering hits into defect instances
  crs.js         EPSG to proj4

src/unleash/     platform integration. WRITTEN TO SPEC, NOT YET RUN.
  client.js      Media Drive GraphQL client, PAT auth, CDN download
  adapt.js       Media Drive metadata -> poses; annotations -> detections

src/pipeline/
  place.js       orchestration: cloud + poses + detections -> defects

web/index.html   self-contained browser tester (1.2 MB, no dependencies)
test/            golden regression tests with real fixtures
docs/            architecture, API notes, and the bugs already found
```

`src/core` is the reusable part, about 600 lines. It runs unchanged in a
browser, a Web Worker, or Node.

---

## Fixtures

Committed:

- `hill60.laz` (1.8 MB) real Unleash export, Port Kembla NSW, EPSG:32756
- `hill60-coco.json` the platform's own annotation export for that session
- `synthetic-coco.json` / `synthetic-poses.csv` 24 views of 6 known points

Not committed, too large:

- `kern.laz` (38 MB) 14.6 M point pipeline corridor, Kern County CA,
  EPSG:32611. Drop it in `test/fixtures/` with `kern-truth.json` to enable
  the sub-metre accuracy assertion.

---

## Known limits

Read `docs/BUGS-FOUND.md` before changing `index3d.js` or `pose.js`. Four bugs
were found and fixed during development, and three of them were silent: they
produced plausible wrong answers rather than errors.

- **Fusion is O(n²).** Fine at a few thousand hits, useless at fifty thousand.
  Needs the voxel hash the ray caster already has.
- **No lens distortion.** Detections near the edge of a wide lens will drift.
  Feed undistorted images, or add the coefficients from the SfM stage.
- **Box centroid, not mask.** `area` is the bounding-box footprint at the hit
  range, not the true defect extent. Media Drive supports `POLYGON` labels, so
  real area is available and unimplemented.
- **First surface only.** Fine on a corridor, needs occlusion work on plant.
- **No octree.** The web tester holds a flat uniform subsample, so a close-up
  can never resolve more than the overview. Potree streams full density for
  what's in view; that is the visible quality gap and it is not a tweak.

---

## Handover checklist

1. Read `docs/API-NOTES.md`. **There is no documented mutation for writing
   annotations back.** That question needs an answer before any production
   work starts, because one of the three options is "the API needs a new
   mutation", which changes the estimate.
2. Confirm the account has API access. It's an optional add-on.
3. Run `npm test` to see the algorithm working on real data.
4. Open `web/index.html`, drop in a LAZ and a COCO export, and watch it place.
5. Ask for the gimbal fields in the COCO export, or skip COCO entirely and
   query Media Drive.
